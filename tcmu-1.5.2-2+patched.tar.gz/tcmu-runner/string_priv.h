#ifndef TCMU_STRING_PRIV_H
#define TCMU_STRING_PRIV_H

#include <sys/types.h>

size_t strlcpy(char *dst, const char *src, size_t size);

#endif
